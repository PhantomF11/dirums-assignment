# How to run
---
- install `node` an `npm`
- run `npm install`
- run `npm run dev`
- open the link is the console.